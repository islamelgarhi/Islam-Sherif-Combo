export const colors = {
  primary: '#17D9FF',
  background: {
    light: '#FFFFFF',
    dark: '#000000'
  },
  text: {
    light: '#000000',
    dark: '#FFFFFF'
  }
} as const;