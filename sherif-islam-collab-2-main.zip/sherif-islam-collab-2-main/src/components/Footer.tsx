import { Footer } from './footer/Footer';
export default Footer;