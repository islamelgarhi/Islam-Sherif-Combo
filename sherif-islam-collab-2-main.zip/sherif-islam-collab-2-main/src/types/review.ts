export interface Review {
  id: string;
  author: string;
  content: string;
  rating: number;
  date: string;
  platform: string;
  status: string;
}